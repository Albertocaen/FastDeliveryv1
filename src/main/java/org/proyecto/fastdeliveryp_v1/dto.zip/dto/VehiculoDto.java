package org.proyecto.fastdeliveryp_v1.dto;

import java.lang.String;
import java.util.List;
import lombok.Data;

@Data
public class VehiculoDto {
  private String placaVehiculo;
  private String marca;
  private String modelo;
  private String color;
}
