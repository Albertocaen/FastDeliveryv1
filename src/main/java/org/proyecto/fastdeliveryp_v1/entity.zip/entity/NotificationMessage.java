package org.proyecto.fastdeliveryp_v1.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class NotificationMessage {
    private Integer pedidoId;
}
